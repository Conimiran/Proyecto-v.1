from django.contrib import admin

# Register your models here.
from .models import Marca,Producto

class ProductoAdmin(admin.ModelAdmin):
    list_display=['modelo','descripcion','size','precio']
    list_editable=['precio']
    search_fields=['nombre']

admin.site.register(Marca)
admin.site.register(Producto,ProductoAdmin)