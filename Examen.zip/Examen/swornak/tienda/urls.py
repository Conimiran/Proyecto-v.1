from .import views 
from django.urls import path


urlpatterns = [
    
    path('',views.inicio,name="inicio"),
    path('catalogo/',views.catalogo,name="catalogo"),
    path("ayuda/", views.ayuda, name="ayuda"),
    path('producto/agregar_producto/', views.agregar_producto, name="agregar_producto"),
    path('producto/listar_productos/', views.listar_productos, name="listar_productos"),
    path('producto/modificar_productos/<id>/', views.modificar_producto, name="modificar_productos"),
    path('eliminar_productos/<id>/', views.eliminar_productos, name="eliminar_productos"),
    path('register/', views.register, name ="register"),
    path('login/', views.login_view, name='login'),
    path('api/buscar_producto/', views.buscar_producto_api, name='buscar_producto_api'),  # Nueva ruta para la API

   
    
]


    
